import socket
def start_client(server_host='127.0.0.1', server_port=65432):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((server_host, server_port))
    print(f"Kết nối đến server {server_host}:{server_port}")
    try:
        while True:
            message = input("Nhập nội dung để gửi đến server (nhập 'exit' để thoát): ")
            if message.lower() == 'exit':
                print("Đóng kết nối.")
                break
            client.send(message.encode('utf-8'))
            response = client.recv(1024).decode('utf-8')
            print(f"[SERVER ()] {response}")
    except KeyboardInterrupt:
        print("\n kết nối đã đóng.")
    finally:
        client.close()
if __name__ == "__main__":
    start_client()
